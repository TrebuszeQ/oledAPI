GRANT ALL PRIVILEGES ON DATABASE "test_flask_notifications" TO your_user_name;
\q
