psql --username=your_games_user_name --dbname=django_games --command="\d games_esrbrating"
psql --username=your_games_user_name --dbname=django_games --command="\d games_game"
psql --username=your_games_user_name --dbname=django_games --command="\d games_player"
