psql --username=your_games_user_name --dbname=django_games --command="SELECT * FROM games_esrbrating; \q"
psql --username=your_games_user_name --dbname=django_games --command="SELECT * FROM games_game;"
psql --username=your_games_user_name --dbname=django_games --command="SELECT * FROM games_player;"
psql --username=your_games_user_name --dbname=django_games --command="SELECT * FROM games_playerscore;"
