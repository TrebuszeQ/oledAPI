psql --username=your_games_user_name --dbname=django_games --command="\dt"
